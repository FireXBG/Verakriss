module.exports = {
    SECRET: 'ad89fnkj4nifkasd89f34uj4naw534289u74'
}
